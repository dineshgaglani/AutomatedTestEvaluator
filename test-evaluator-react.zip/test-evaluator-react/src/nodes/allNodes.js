export default [{
    id: `1`,
    type: 'textUpdater',
    data: { label: 'New Node' },
    position: { x: 100, y: 100 },
    style: { backgroundColor: '#ff0072', color: 'white' },
}
];
