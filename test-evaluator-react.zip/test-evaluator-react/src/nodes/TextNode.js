import { useCallback, useState } from 'react';
import { Handle, Position } from 'reactflow';
 
const handleStyle = { left: 10 };
 
function TextUpdaterNode({ data, xPos, yPos }) {

  console.log(`Text Updated Node change: ${JSON.stringify(data)}, x: ${xPos}`)
  const [nodeLabel, setNodeLabel] = useState("") 
  const [activationEligibility, setActivationEligibility] = useState("") 
  const [activationTask, setActivationTask] = useState("") 
  
  const onChangeNodeLabel = useCallback((evt) => {
    setNodeLabel(evt.target.value)
  }, []);

  const onChangeActivationEligibility = useCallback((evt) => {
    setActivationEligibility(evt.target.value)
  }, []);

  const onChangeActivationTask = useCallback((evt) => {
    setActivationTask(evt.target.value)
  }, []);
 
  return (
    <>
      <Handle type="target" position={Position.Top} />
      <div>
        <label style={{backgroundColor: "lightblue" }}>nodeId: {data.nodeId}</label>
        <label htmlFor="nodeLabel">Node Label:</label>
        <input id="nodeLabel" name="nodeLabel" value={nodeLabel} onChange={onChangeNodeLabel} className="nodrag" />
        <br/>
        <label htmlFor="activationEligibility">ActivationEligibility</label>
        <input id="activationEligibility" value={activationEligibility} onChange={onChangeActivationEligibility} className="nodrag" />
        <br/>
        <label htmlFor="activationTask">ActivationTask</label>
        <input id="activationTask" value={activationTask} onChange={onChangeActivationTask} className="nodrag" />
      </div>
      <Handle type="source" position={Position.Bottom} id="a" />
      <Handle
        type="source"
        position={Position.Bottom}
        id="b"
        style={handleStyle}
      />
    </>
  );
}

export default TextUpdaterNode;